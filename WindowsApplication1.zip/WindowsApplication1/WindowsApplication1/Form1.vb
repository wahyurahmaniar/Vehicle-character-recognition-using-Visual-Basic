﻿Imports System.Drawing
Imports System.Drawing.Drawing2D

Public Class Form1

    Dim Current_X, Current_Y As Integer
    Dim Komsu_Sayisi As Byte
    Dim Piksel_Komsu_Sayisi(1800, 1200) As Byte
    Dim Piksel_Komsu_Listesi(1800, 1200) As String
    Dim Piksel_Durum(1800, 1200) As Boolean
    Dim Piksel_Sil As Boolean
    Dim Piksel_Silme As Boolean
    Dim kalinlik_iki As Boolean
    Dim iskelet As Boolean

    Public Shared Function ResizeImage(ByVal image As Bitmap, ByVal size As Size, Optional ByVal preserveAspectRatio As Boolean = True) As Bitmap
        Dim newWidth As Integer
        Dim newHeight As Integer
        If preserveAspectRatio Then
            Dim originalWidth As Integer = image.Width
            Dim originalHeight As Integer = image.Height
            newWidth = size.Width
            newHeight = size.Height
        End If
        Dim newImage As New Bitmap(newWidth, newHeight)
        Using gr As Graphics = Graphics.FromImage(newImage)
            gr.InterpolationMode = InterpolationMode.Bilinear
            gr.DrawImage(image, 0, 0, newWidth, newHeight)
        End Using
        Return newImage
    End Function

    Private Sub Button1_Click(sender As System.Object, e As System.EventArgs) Handles Button1.Click
        Dim ofd As New OpenFileDialog

        If ofd.ShowDialog = DialogResult.OK Then
            If ofd.FileName <> String.Empty Then
                picPlate.Image = Bitmap.FromFile(ofd.FileName)
                Dim ori As New Bitmap(picPlate.Image)
                Dim w, h As Integer
                w = 700
                h = 300
                Dim newImage As New Bitmap(w, h)
                Using gr As Graphics = Graphics.FromImage(newImage)
                    gr.InterpolationMode = InterpolationMode.Bilinear
                    gr.DrawImage(ori, 0, 0, w, h)
                End Using
                picPlate.Image = newImage
                PictureBox2.Image = newImage
            End If
        End If
        txtChar.Text = "0"
        txtResult.Text = ""
    End Sub


    Private Sub Button3_Click(sender As System.Object, e As System.EventArgs) Handles Button3.Click
        Call bw_image()
        'Call small_pixel()
        PictureBox2.Image = picPlate.Image
    End Sub

    Sub bw_image()
        Try
            Dim img As Bitmap = New Bitmap(picPlate.Image)
            Dim c As Color
            Dim i As Integer = 0
            Do While (i < img.Width)
                Dim j As Integer = 0
                Do While (j < img.Height)
                    c = img.GetPixel(i, j)
                    Dim r As Integer = 0
                    r = Convert.ToInt16(c.R)
                    Dim g As Integer = 0
                    g = Convert.ToInt16(c.G)
                    Dim b As Integer = 0
                    b = Convert.ToInt16(c.B)
                    Dim ans As Integer = ((r + g + b) / 3)
                    If (ans > 128) Then
                        r = 255
                        g = 255
                        b = 255
                    Else
                        r = 0
                        g = 0
                        b = 0
                    End If
                    c = Color.FromArgb(r, g, b)
                    img.SetPixel(i, j, c)
                    j = j + 1
                Loop
                i = i + 1
            Loop
            picPlate.Image = img

        Catch ex As Exception
        End Try
    End Sub

    Sub bw_image2()
        Try
            Dim img As Bitmap = New Bitmap(PictureBox1.Image)
            Dim c As Color
            Dim i As Integer = 0
            Do While (i < img.Width)
                Dim j As Integer = 0
                Do While (j < img.Height)
                    c = img.GetPixel(i, j)
                    Dim r As Integer = 0
                    r = Convert.ToInt16(c.R)
                    Dim g As Integer = 0
                    g = Convert.ToInt16(c.G)
                    Dim b As Integer = 0
                    b = Convert.ToInt16(c.B)
                    Dim ans As Integer = (r + g + b) / 3
                    If (ans > 128) Then
                        r = 255
                        g = 255
                        b = 255
                    Else
                        r = 0
                        g = 0
                        b = 0
                    End If
                    c = Color.FromArgb(r, g, b)
                    img.SetPixel(i, j, c)
                    j = j + 1
                Loop
                i = i + 1
            Loop
            PictureBox1.Image = img

        Catch ex As Exception
        End Try
    End Sub


    Sub bw_image3()
        Try
            Dim img As Bitmap = New Bitmap(PictureBox3.Image)
            Dim c As Color
            Dim i As Integer = 0
            Do While (i < img.Width)
                Dim j As Integer = 0
                Do While (j < img.Height)
                    c = img.GetPixel(i, j)
                    Dim r As Integer = 0
                    r = Convert.ToInt16(c.R)
                    Dim g As Integer = 0
                    g = Convert.ToInt16(c.G)
                    Dim b As Integer = 0
                    b = Convert.ToInt16(c.B)
                    Dim ans As Integer = (r + g + b) / 3
                    If (ans > 128) Then
                        r = 255
                        g = 255
                        b = 255
                    Else
                        r = 0
                        g = 0
                        b = 0
                    End If
                    c = Color.FromArgb(r, g, b)
                    img.SetPixel(i, j, c)
                    j = j + 1
                Loop
                i = i + 1
            Loop
            PictureBox3.Image = img

        Catch ex As Exception
        End Try
    End Sub

    Private Sub Button4_Click(sender As System.Object, e As System.EventArgs) Handles Button4.Click
        Dim fr_bm As New Bitmap(picPlate.Image)
        Dim w, h As Integer

        'crop rectangle outer
        w = fr_bm.Width
        h = fr_bm.Height

        Dim to_bm As New Bitmap(picPlate.Image)
        Dim gr As Graphics = Graphics.FromImage(to_bm)
        Dim fr_rect As New Rectangle(40, 50, w - 60, h - 90)
        Dim to_rect As New Rectangle(0, 0, w, h)
        gr.DrawImage(fr_bm, to_rect, fr_rect, GraphicsUnit.Pixel)

        picPlate.Image = to_bm

        Call crop_image()
        Call crop_image()

        PictureBox2.Image = picPlate.Image
    End Sub

    Private Sub crop_image()
        Dim w, h As Integer
        Dim minX, maxX As Integer
        Dim minY, maxY As Integer
        Dim x, y As Integer
        Dim z1, z2 As Integer

        'crop based on the outer white pixel
        Dim img As New Bitmap(picPlate.Image)

        w = img.Width
        h = img.Height

        z1 = 0
        z2 = 0

        For y = 0 To h - 1
            For x = 0 To w - 1
                Dim c As Color = img.GetPixel(x, y)
                On Error Resume Next
                If c.ToArgb() = Color.White.ToArgb() Then
                    z1 = z1 + 1
                    If z1 = 1 Then
                        minX = x
                        minY = y
                    End If
                    If x <= minX Then
                        minX = x
                    Else
                        z2 = z2 + 1
                        If z2 = 1 Then
                            maxX = x
                        End If
                        If x > maxX Then
                            maxX = x
                        End If
                    End If
                    If y < minY Then
                        minY = y
                    Else
                        maxY = y
                    End If
                End If
            Next
        Next

        Dim gr As Graphics = Graphics.FromImage(img)
        Dim fr_rect2 As New Rectangle(minX + 2, minY, maxX, maxY)
        Dim to_rect2 As New Rectangle(0, 0, w - 5, h)
        gr.DrawImage(img, to_rect2, fr_rect2, GraphicsUnit.Pixel)

        picPlate.Image = img
        Call bw_image()
    End Sub

    Private Sub crop_image2()
        Dim w, h As Integer
        Dim minX, maxX As Integer
        Dim minY, maxY As Integer
        Dim x, y As Integer
        Dim z1, z2 As Integer

        'crop based on the outer white pixel
        Dim img As New Bitmap(PictureBox1.Image)

        w = img.Width
        h = img.Height

        z1 = 0
        z2 = 0

        For y = 0 To h - 1
            For x = 0 To w - 1
                Dim c As Color = img.GetPixel(x, y)
                On Error Resume Next
                If c.ToArgb() = Color.White.ToArgb() Then
                    z1 = z1 + 1
                    If z1 = 1 Then
                        minX = x
                        minY = y
                    End If
                    If x <= minX Then
                        minX = x
                    Else
                        z2 = z2 + 1
                        If z2 = 1 Then
                            maxX = x
                        End If
                        If x > maxX Then
                            maxX = x
                        End If
                    End If
                    If y < minY Then
                        minY = y
                    Else
                        maxY = y
                    End If
                End If
            Next
        Next

        Dim gr As Graphics = Graphics.FromImage(img)
        Dim fr_rect2 As New Rectangle(minX + 5, minY, maxX, maxY)
        Dim to_rect2 As New Rectangle(0, 0, w, h)
        gr.DrawImage(img, to_rect2, fr_rect2, GraphicsUnit.Pixel)

        PictureBox1.Image = img
        Call bw_image2()

    End Sub

    Private Sub crop_image3()
        Dim w, h As Integer
        Dim minX As Integer
        Dim x, y As Integer
        Dim z As Integer

        'crop based on the outer white pixel
        Dim img As New Bitmap(picPlate.Image)

        w = img.Width
        h = img.Height

        z = 0

        For y = 0 To h - 1
            For x = 0 To w - 1
                Dim c As Color = img.GetPixel(x, y)
                On Error Resume Next
                If c.ToArgb() = Color.White.ToArgb() Then
                    z = z + 1
                    If z = 1 Then
                        minX = x
                    End If
                    If x <= minX Then
                        minX = x
                    End If
                End If
            Next
        Next

        Dim gr As Graphics = Graphics.FromImage(img)
        Dim fr_rect2 As New Rectangle(minX + 5, 0, w - minX, h)
        Dim to_rect2 As New Rectangle(0, 0, w, h)
        gr.DrawImage(img, to_rect2, fr_rect2, GraphicsUnit.Pixel)

        picPlate.Image = img
        Call bw_image()

    End Sub

    Private Sub Button2_Click(sender As System.Object, e As System.EventArgs) Handles Button2.Click

        Call segmented()
        crop1.Image = PictureBox1.Image
        Call crop_image3()
        Call segmented()
        crop2.Image = PictureBox1.Image
        Call crop_image3()
        Call segmented()
        crop3.Image = PictureBox1.Image
        Call crop_image3()
        Call segmented()
        crop4.Image = PictureBox1.Image
        Call crop_image3()
        Call segmented()
        crop5.Image = PictureBox1.Image
        Call crop_image3()
        Call segmented()
        crop6.Image = PictureBox1.Image
        Call crop_image3()
        Call segmented()
        crop7.Image = PictureBox1.Image
        Call crop_image3()
        Call segmented()
        crop8.Image = PictureBox1.Image

    End Sub

    Private Sub segmented()
        Dim w, h As Integer
        Dim minX, maxX As Integer
        Dim minY, maxY As Integer
        Dim x, y As Integer
        Dim z1, z2, z3 As Integer
        Dim img As New Bitmap(picPlate.Image)
        Dim img2 As New Bitmap(picPlate.Image)

        w = img.Width
        h = img.Height

        z1 = 0
        z2 = 0
        z3 = 0

        Call cek_white()

        For y = 0 To h - 1
            For x = 0 To w - 1
                Dim c As Color = img.GetPixel(x, y)
                On Error Resume Next
                If c.ToArgb() = Color.White.ToArgb() Then
                    z1 = z1 + 1
                    If z1 = 1 Then
                        minX = x
                        minY = y
                    End If
                    If x <= minX Then
                        minX = x
                    End If
                    If y < minY Then
                        minY = y
                    Else
                        maxY = y
                    End If
                End If

                z3 = 0

                If c.ToArgb() = Color.Black.ToArgb() Then
                    If y = 0 Then
                        Dim y2 As Integer
                        For y2 = 0 To h - 1
                            Dim c2 As Color = img.GetPixel(x, y2)
                            If c2.ToArgb() = Color.Black.ToArgb() Then
                                z3 = z3 + 1
                                If z3 > 290 Then
                                    z2 = z2 + 1
                                    If z2 = 1 Then
                                        maxX = x
                                    End If
                                End If
                            End If
                        Next
                    End If
                End If
            Next
        Next

        Dim gr As Graphics = Graphics.FromImage(img)
        Dim fr_rect As New Rectangle(minX, minY, maxX, maxY)
        Dim to_rect As New Rectangle(0, 0, w, h)
        gr.DrawImage(img, to_rect, fr_rect, GraphicsUnit.Pixel)

        Dim gr2 As Graphics = Graphics.FromImage(img2)
        Dim fr_rect2 As New Rectangle(maxX, 0, w - maxX, h)
        Dim to_rect2 As New Rectangle(0, 0, w, h)
        gr2.DrawImage(img2, to_rect2, fr_rect2, GraphicsUnit.Pixel)

        PictureBox1.Image = img

        Call cek_line()
        If CInt(Label2.Text) > 0 Then
            Call crop_image3()
            Call segmented()
        Else
            If CInt(Label4.Text) > 0 Then
                picPlate.Image = img2
                Call crop_image2()
                txtChar.Text = CInt(txtChar.Text) + 1
            End If
        End If
    End Sub

    Sub cek_white()
        Dim y As Integer
        Dim white As Integer
        Dim img As New Bitmap(picPlate.Image)

        white = 0

        For y = 0 To img.Height - 1
            Dim c As Color = img.GetPixel(0, y)
            If c.ToArgb() = Color.White.ToArgb() Then
                white = white + 1
            End If
        Next

        If (white < 200) Then
            Call crop_image3()
        End If

    End Sub

    Sub cek_line()
        Dim w, h As Integer
        Dim minX, maxX As Integer
        Dim minY, maxY As Integer
        Dim x, y As Integer
        Dim z1, z2, z3 As Integer
        Dim img As New Bitmap(PictureBox1.Image)
        Dim white As Integer

        w = img.Width
        h = img.Height

        z1 = 0
        z2 = 0
        z3 = 0
        white = 0

        For y = 0 To h - 1
            For x = 0 To w - 1
                Dim c As Color = img.GetPixel(x, y)
                On Error Resume Next
                If c.ToArgb() = Color.White.ToArgb() Then
                    white = white + 1
                    z1 = z1 + 1
                    If z1 = 1 Then
                        minX = x
                        minY = y
                    End If
                    If x <= minX Then
                        minX = x
                    End If
                    If y < minY Then
                        minY = y
                    Else
                        maxY = y
                    End If
                End If

                z3 = 0

                If c.ToArgb() = Color.Black.ToArgb() Then
                    If y = 0 Then
                        Dim y2 As Integer
                        For y2 = 0 To h - 1
                            Dim c2 As Color = img.GetPixel(x, y2)
                            If c2.ToArgb() = Color.Black.ToArgb() Then
                                z3 = z3 + 1
                                If z3 > h - 1 Then
                                    z2 = z2 + 1
                                End If
                            End If
                        Next
                    End If
                End If
            Next
        Next

        If white > 0 And white < 10000 Then
            z2 = z2 + 1
        End If
        If white = 0 Then
            Label4.Text = 0
            z2 = 0
        End If

        Label2.Text = z2

    End Sub

    Sub invert()
        Try
            Dim img As Bitmap = New Bitmap(PictureBox1.Image)
            Dim c As Color
            Dim i As Integer = 0
            Do While (i < img.Width)
                Dim j As Integer = 0
                Do While (j < img.Height)
                    c = img.GetPixel(i, j)
                    Dim r As Integer = 0
                    r = Convert.ToInt16(c.R)
                    Dim g As Integer = 0
                    g = Convert.ToInt16(c.G)
                    Dim b As Integer = 0
                    b = Convert.ToInt16(c.B)
                    Dim ans As Integer = (r + g + b) / 3
                    If (ans > 128) Then
                        r = 0
                        g = 0
                        b = 0
                    Else
                        r = 255
                        g = 255
                        b = 255
                    End If
                    c = Color.FromArgb(r, g, b)
                    img.SetPixel(i, j, c)
                    j = j + 1
                Loop
                i = i + 1
            Loop
            PictureBox1.Image = img

        Catch ex As Exception
        End Try
    End Sub


    Private Sub Button7_Click(sender As System.Object, e As System.EventArgs) Handles Button7.Click
        PictureBox1.Image = crop1.Image
        Call scaling()
        Call bw_image2()
        crop1.Image = PictureBox1.Image

        PictureBox1.Image = crop2.Image
        Call scaling()
        Call bw_image2()
        crop2.Image = PictureBox1.Image

        PictureBox1.Image = crop3.Image
        Call scaling()
        Call bw_image2()
        crop3.Image = PictureBox1.Image

        PictureBox1.Image = crop4.Image
        Call scaling()
        Call bw_image2()
        crop4.Image = PictureBox1.Image

        PictureBox1.Image = crop5.Image
        Call scaling()
        Call bw_image2()
        crop5.Image = PictureBox1.Image

        PictureBox1.Image = crop6.Image
        Call scaling()
        Call bw_image2()
        crop6.Image = PictureBox1.Image

        PictureBox1.Image = crop7.Image
        Call scaling()
        Call bw_image2()
        crop7.Image = PictureBox1.Image

        PictureBox1.Image = crop8.Image
        Call scaling()
        Call bw_image2()
        crop8.Image = PictureBox1.Image
    End Sub

    Sub scaling()
        Dim ori As New Bitmap(PictureBox1.Image)
        Dim w, h As Integer

        w = 10
        h = 15

        Dim newImage As New Bitmap(w, h)
        Using gr As Graphics = Graphics.FromImage(newImage)
            gr.InterpolationMode = InterpolationMode.HighQualityBicubic
            gr.DrawImage(ori, 0, 0, w, h)
        End Using

        PictureBox1.Image = newImage
        Call invert()
        Call bw_image2()

    End Sub

    Private Sub Button6_Click(sender As System.Object, e As System.EventArgs) Handles Button6.Click
        Dim savefiledialog1 As New SaveFileDialog
        savefiledialog1.Title = "Save File"
        savefiledialog1.FileName = "*.jpg"
        savefiledialog1.Filter = "Jpeg |*.jpg"
        If savefiledialog1.ShowDialog() = DialogResult.OK Then
            crop1.Image.Save(savefiledialog1.FileName, System.Drawing.Imaging.ImageFormat.Jpeg)
        End If
    End Sub

    Private Sub Button8_Click(sender As System.Object, e As System.EventArgs) Handles Button8.Click
        Dim savefiledialog1 As New SaveFileDialog
        savefiledialog1.Title = "Save File"
        savefiledialog1.FileName = "*.jpg"
        savefiledialog1.Filter = "Jpeg |*.jpg"
        If savefiledialog1.ShowDialog() = DialogResult.OK Then
            crop2.Image.Save(savefiledialog1.FileName, System.Drawing.Imaging.ImageFormat.Jpeg)
        End If
    End Sub

    Private Sub Button9_Click(sender As System.Object, e As System.EventArgs) Handles Button9.Click
        Dim savefiledialog1 As New SaveFileDialog
        savefiledialog1.Title = "Save File"
        savefiledialog1.FileName = "*.jpg"
        savefiledialog1.Filter = "Jpeg |*.jpg"
        If savefiledialog1.ShowDialog() = DialogResult.OK Then
            crop3.Image.Save(savefiledialog1.FileName, System.Drawing.Imaging.ImageFormat.Jpeg)
        End If
    End Sub

    Private Sub Button10_Click(sender As System.Object, e As System.EventArgs) Handles Button10.Click
        Dim savefiledialog1 As New SaveFileDialog
        savefiledialog1.Title = "Save File"
        savefiledialog1.FileName = "*.jpg"
        savefiledialog1.Filter = "Jpeg |*.jpg"
        If savefiledialog1.ShowDialog() = DialogResult.OK Then
            crop4.Image.Save(savefiledialog1.FileName, System.Drawing.Imaging.ImageFormat.Jpeg)
        End If
    End Sub

    Private Sub Button14_Click(sender As System.Object, e As System.EventArgs) Handles Button14.Click
        Dim savefiledialog1 As New SaveFileDialog
        savefiledialog1.Title = "Save File"
        savefiledialog1.FileName = "*.jpg"
        savefiledialog1.Filter = "Jpeg |*.jpg"
        If savefiledialog1.ShowDialog() = DialogResult.OK Then
            crop5.Image.Save(savefiledialog1.FileName, System.Drawing.Imaging.ImageFormat.Jpeg)
        End If
    End Sub

    Private Sub Button13_Click(sender As System.Object, e As System.EventArgs) Handles Button13.Click
        Dim savefiledialog1 As New SaveFileDialog
        savefiledialog1.Title = "Save File"
        savefiledialog1.FileName = "*.jpg"
        savefiledialog1.Filter = "Jpeg |*.jpg"
        If savefiledialog1.ShowDialog() = DialogResult.OK Then
            crop6.Image.Save(savefiledialog1.FileName, System.Drawing.Imaging.ImageFormat.Jpeg)
        End If
    End Sub

    Private Sub Button12_Click(sender As System.Object, e As System.EventArgs) Handles Button12.Click
        Dim savefiledialog1 As New SaveFileDialog
        savefiledialog1.Title = "Save File"
        savefiledialog1.FileName = "*.jpg"
        savefiledialog1.Filter = "Jpeg |*.jpg"
        If savefiledialog1.ShowDialog() = DialogResult.OK Then
            crop7.Image.Save(savefiledialog1.FileName, System.Drawing.Imaging.ImageFormat.Jpeg)
        End If
    End Sub

    Private Sub Button11_Click(sender As System.Object, e As System.EventArgs) Handles Button11.Click
        Dim savefiledialog1 As New SaveFileDialog
        savefiledialog1.Title = "Save File"
        savefiledialog1.FileName = "*.jpg"
        savefiledialog1.Filter = "Jpeg |*.jpg"
        If savefiledialog1.ShowDialog() = DialogResult.OK Then
            crop8.Image.Save(savefiledialog1.FileName, System.Drawing.Imaging.ImageFormat.Jpeg)
        End If
    End Sub

    Private Sub Form1_Load(sender As System.Object, e As System.EventArgs) Handles MyBase.Load
        txtChar.Text = "0"
        txtResult.Text = ""
    End Sub

    Private Sub Button5_Click(sender As System.Object, e As System.EventArgs) Handles Button5.Click
        Call c1()
        Call c2()
        Call c3()
        Call c4()
        Call c5()
        Call c6()
        Call c7()
        Call c8()
        txtResult.Text = TextBox1.Text & TextBox2.Text & TextBox3.Text & TextBox4.Text & TextBox5.Text & TextBox6.Text & TextBox7.Text & TextBox8.Text
    End Sub

    Sub c1()
        Dim i, j As Integer
        Dim x, y As Integer
        Dim imgPictures(0 To 110) As Image
        Dim total As Integer
        Dim eq_color As Color = Color.White
        Dim ne_color As Color = Color.Red

        PictureBox1.Image = crop1.Image
        Dim img As New Bitmap(PictureBox1.Image)
        Label5.Text = ""
        Label6.Text = ""

        For x = 0 To 107
            total = 0
            y = x + 1
            imgPictures(x) = Image.FromFile("database\" & y.ToString & ".jpg")
            PictureBox3.Image = imgPictures(x)
            Call bw_image3()
            Dim img2 As New Bitmap(PictureBox3.Image)

            For i = 0 To img.Width - 1
                For j = 0 To img.Height - 1
                    If img.GetPixel(i, j).Equals(img2.GetPixel(i, j)) Then
                        total = total + 1
                    End If
                Next j
            Next i

            If total > 140 Then
                Label6.Text = total.ToString
                Label5.Text = y.ToString
                Call letter()
                TextBox1.Text = txtResult.Text
            End If

        Next
    End Sub

    Sub c2()
        Dim i, j As Integer
        Dim x, y As Integer
        Dim imgPictures(0 To 110) As Image
        Dim total As Integer
        Dim eq_color As Color = Color.White
        Dim ne_color As Color = Color.Red

        PictureBox1.Image = crop2.Image
        Dim img As New Bitmap(PictureBox1.Image)
        Label5.Text = ""
        Label6.Text = ""
        For x = 0 To 107
            total = 0
            y = x + 1
            imgPictures(x) = Image.FromFile("database\" & y.ToString & ".jpg")
            PictureBox3.Image = imgPictures(x)
            Call bw_image3()
            Dim img2 As New Bitmap(PictureBox3.Image)

            For i = 0 To img.Width - 1
                For j = 0 To img.Height - 1
                    If img.GetPixel(i, j).Equals(img2.GetPixel(i, j)) Then
                        total = total + 1
                    End If
                Next j
            Next i

            If total > 140 Then
                Label6.Text = total.ToString
                Label5.Text = y.ToString
                Call letter()
                TextBox2.Text = txtResult.Text
            End If

        Next
    End Sub

    Sub c3()
        Dim i, j As Integer
        Dim x, y As Integer
        Dim imgPictures(0 To 110) As Image
        Dim total As Integer
        Dim eq_color As Color = Color.White
        Dim ne_color As Color = Color.Red

        PictureBox1.Image = crop3.Image
        Dim img As New Bitmap(PictureBox1.Image)
        Label5.Text = ""
        Label6.Text = ""
        For x = 0 To 107
            total = 0
            y = x + 1
            imgPictures(x) = Image.FromFile("database\" & y.ToString & ".jpg")
            PictureBox3.Image = imgPictures(x)
            Call bw_image3()
            Dim img2 As New Bitmap(PictureBox3.Image)

            For i = 0 To img.Width - 1
                For j = 0 To img.Height - 1
                    If img.GetPixel(i, j).Equals(img2.GetPixel(i, j)) Then
                        total = total + 1
                    End If
                Next j
            Next i

            If total > 140 Then
                Label6.Text = total.ToString
                Label5.Text = y.ToString
                Call letter()
                TextBox3.Text = txtResult.Text
            End If

        Next
    End Sub

    Sub c4()
        Dim i, j As Integer
        Dim x, y As Integer
        Dim imgPictures(0 To 110) As Image
        Dim total As Integer
        Dim eq_color As Color = Color.White
        Dim ne_color As Color = Color.Red

        PictureBox1.Image = crop4.Image
        Dim img As New Bitmap(PictureBox1.Image)
        Label5.Text = ""
        Label6.Text = ""
        For x = 0 To 107
            total = 0
            y = x + 1
            imgPictures(x) = Image.FromFile("database\" & y.ToString & ".jpg")
            PictureBox3.Image = imgPictures(x)
            Call bw_image3()
            Dim img2 As New Bitmap(PictureBox3.Image)

            For i = 0 To img.Width - 1
                For j = 0 To img.Height - 1
                    If img.GetPixel(i, j).Equals(img2.GetPixel(i, j)) Then
                        total = total + 1
                    End If
                Next j
            Next i

            If total > 140 Then
                Label6.Text = total.ToString
                Label5.Text = y.ToString
                Call letter()
                TextBox4.Text = txtResult.Text
            End If

        Next
    End Sub


    Sub c5()
        Dim i, j As Integer
        Dim x, y As Integer
        Dim imgPictures(0 To 110) As Image
        Dim total As Integer
        Dim eq_color As Color = Color.White
        Dim ne_color As Color = Color.Red

        PictureBox1.Image = crop5.Image
        Dim img As New Bitmap(PictureBox1.Image)
        Label5.Text = ""
        Label6.Text = ""
        For x = 0 To 107
            total = 0
            y = x + 1
            imgPictures(x) = Image.FromFile("database\" & y.ToString & ".jpg")
            PictureBox3.Image = imgPictures(x)
            Call bw_image3()
            Dim img2 As New Bitmap(PictureBox3.Image)

            For i = 0 To img.Width - 1
                For j = 0 To img.Height - 1
                    If img.GetPixel(i, j).Equals(img2.GetPixel(i, j)) Then
                        total = total + 1
                    End If
                Next j
            Next i

            If total > 140 Then
                Label6.Text = total.ToString
                Label5.Text = y.ToString
                Call letter()
                TextBox5.Text = txtResult.Text
            End If

        Next
    End Sub

    Sub c6()
        Dim i, j As Integer
        Dim x, y As Integer
        Dim imgPictures(0 To 110) As Image
        Dim total As Integer
        Dim eq_color As Color = Color.White
        Dim ne_color As Color = Color.Red

        PictureBox1.Image = crop6.Image
        Dim img As New Bitmap(PictureBox1.Image)
        Label5.Text = ""
        Label6.Text = ""
        For x = 0 To 107
            total = 0
            y = x + 1
            imgPictures(x) = Image.FromFile("database\" & y.ToString & ".jpg")
            PictureBox3.Image = imgPictures(x)
            Call bw_image3()
            Dim img2 As New Bitmap(PictureBox3.Image)

            For i = 0 To img.Width - 1
                For j = 0 To img.Height - 1
                    If img.GetPixel(i, j).Equals(img2.GetPixel(i, j)) Then
                        total = total + 1
                    End If
                Next j
            Next i

            If total > 140 Then
                Label6.Text = total.ToString
                Label5.Text = y.ToString
                Call letter()
                TextBox6.Text = txtResult.Text
            End If

        Next
    End Sub

    Sub c7()
        Dim i, j As Integer
        Dim x, y As Integer
        Dim imgPictures(0 To 110) As Image
        Dim total As Integer
        Dim eq_color As Color = Color.White
        Dim ne_color As Color = Color.Red

        PictureBox1.Image = crop7.Image
        Dim img As New Bitmap(PictureBox1.Image)
        Label5.Text = ""
        Label6.Text = ""
        For x = 0 To 107
            total = 0
            y = x + 1
            imgPictures(x) = Image.FromFile("database\" & y.ToString & ".jpg")
            PictureBox3.Image = imgPictures(x)
            Call bw_image3()
            Dim img2 As New Bitmap(PictureBox3.Image)

            For i = 0 To img.Width - 1
                For j = 0 To img.Height - 1
                    If img.GetPixel(i, j).Equals(img2.GetPixel(i, j)) Then
                        total = total + 1
                    End If
                Next j
            Next i

            If total > 140 Then
                Label6.Text = total.ToString
                Label5.Text = y.ToString
                Call letter()
                TextBox7.Text = txtResult.Text
            End If

        Next
    End Sub

    Sub c8()
        Dim i, j As Integer
        Dim x, y As Integer
        Dim imgPictures(0 To 110) As Image
        Dim total As Integer
        Dim eq_color As Color = Color.White
        Dim ne_color As Color = Color.Red

        PictureBox1.Image = crop8.Image
        Dim img As New Bitmap(PictureBox1.Image)
        Label5.Text = ""
        Label6.Text = ""
        For x = 0 To 107
            total = 0
            y = x + 1
            imgPictures(x) = Image.FromFile("database\" & y.ToString & ".jpg")
            PictureBox3.Image = imgPictures(x)
            Call bw_image3()
            Dim img2 As New Bitmap(PictureBox3.Image)

            For i = 0 To img.Width - 1
                For j = 0 To img.Height - 1
                    If img.GetPixel(i, j).Equals(img2.GetPixel(i, j)) Then
                        total = total + 1
                    End If
                Next j
            Next i

            If total > 140 Then
                Label6.Text = total.ToString
                Label5.Text = y.ToString
                Call letter()
                TextBox8.Text = txtResult.Text
            End If

        Next
    End Sub

    Sub letter()
        Dim cek As Integer
        Dim huruf As String

        huruf = ""
        cek = CInt(Label5.Text)

        Select Case cek
            Case 1 To 3
                huruf = "0"
            Case 4 To 6
                huruf = "1"
            Case 7 To 9
                huruf = "2"
            Case 10 To 12
                huruf = "3"
            Case 13 To 15
                huruf = "4"
            Case 16 To 18
                huruf = "5"
            Case 19 To 21
                huruf = "6"
            Case 22 To 24
                huruf = "7"
            Case 25 To 27
                huruf = "8"
            Case 28 To 30
                huruf = "9"
            Case 31 To 33
                huruf = "A"
            Case 34 To 36
                huruf = "B"
            Case 37 To 39
                huruf = "C"
            Case 40 To 42
                huruf = "D"
            Case 43 To 45
                huruf = "E"
            Case 46 To 48
                huruf = "F"
            Case 49 To 51
                huruf = "G"
            Case 52 To 54
                huruf = "H"
            Case 55 To 57
                huruf = "I"
            Case 58 To 60
                huruf = "J"
            Case 61 To 63
                huruf = "K"
            Case 64 To 66
                huruf = "L"
            Case 67 To 69
                huruf = "M"
            Case 70 To 72
                huruf = "N"
            Case 73 To 75
                huruf = "O"
            Case 76 To 78
                huruf = "P"
            Case 79 To 81
                huruf = "Q"
            Case 82 To 84
                huruf = "R"
            Case 85 To 87
                huruf = "S"
            Case 88 To 90
                huruf = "T"
            Case 91 To 93
                huruf = "U"
            Case 94 To 96
                huruf = "V"
            Case 97 To 99
                huruf = "W"
            Case 100 To 102
                huruf = "X"
            Case 103 To 105
                huruf = "Y"
            Case 106 To 108
                huruf = "Z"
        End Select
        Label5.Text = ""
        Label6.Text = ""
        txtResult.Text = huruf
    End Sub

End Class
