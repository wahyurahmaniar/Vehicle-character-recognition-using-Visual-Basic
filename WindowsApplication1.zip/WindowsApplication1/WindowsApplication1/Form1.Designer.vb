﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Me.Button1 = New System.Windows.Forms.Button()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.Button2 = New System.Windows.Forms.Button()
        Me.txtResult = New System.Windows.Forms.TextBox()
        Me.Button3 = New System.Windows.Forms.Button()
        Me.Button4 = New System.Windows.Forms.Button()
        Me.Button5 = New System.Windows.Forms.Button()
        Me.Timer1 = New System.Windows.Forms.Timer(Me.components)
        Me.Label2 = New System.Windows.Forms.Label()
        Me.txtChar = New System.Windows.Forms.TextBox()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.Button7 = New System.Windows.Forms.Button()
        Me.Button6 = New System.Windows.Forms.Button()
        Me.Button8 = New System.Windows.Forms.Button()
        Me.Button9 = New System.Windows.Forms.Button()
        Me.Button10 = New System.Windows.Forms.Button()
        Me.Button11 = New System.Windows.Forms.Button()
        Me.Button12 = New System.Windows.Forms.Button()
        Me.Button13 = New System.Windows.Forms.Button()
        Me.Button14 = New System.Windows.Forms.Button()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.PictureBox3 = New System.Windows.Forms.PictureBox()
        Me.picPlate = New System.Windows.Forms.PictureBox()
        Me.PictureBox2 = New System.Windows.Forms.PictureBox()
        Me.PictureBox1 = New System.Windows.Forms.PictureBox()
        Me.crop8 = New System.Windows.Forms.PictureBox()
        Me.crop7 = New System.Windows.Forms.PictureBox()
        Me.crop6 = New System.Windows.Forms.PictureBox()
        Me.crop5 = New System.Windows.Forms.PictureBox()
        Me.crop4 = New System.Windows.Forms.PictureBox()
        Me.crop3 = New System.Windows.Forms.PictureBox()
        Me.crop2 = New System.Windows.Forms.PictureBox()
        Me.crop1 = New System.Windows.Forms.PictureBox()
        Me.TextBox1 = New System.Windows.Forms.TextBox()
        Me.TextBox2 = New System.Windows.Forms.TextBox()
        Me.TextBox3 = New System.Windows.Forms.TextBox()
        Me.TextBox4 = New System.Windows.Forms.TextBox()
        Me.TextBox5 = New System.Windows.Forms.TextBox()
        Me.TextBox6 = New System.Windows.Forms.TextBox()
        Me.TextBox7 = New System.Windows.Forms.TextBox()
        Me.TextBox8 = New System.Windows.Forms.TextBox()
        CType(Me.PictureBox3, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.picPlate, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox2, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.crop8, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.crop7, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.crop6, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.crop5, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.crop4, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.crop3, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.crop2, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.crop1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'Button1
        '
        Me.Button1.Font = New System.Drawing.Font("PMingLiU", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(136, Byte))
        Me.Button1.Location = New System.Drawing.Point(37, 348)
        Me.Button1.Name = "Button1"
        Me.Button1.Size = New System.Drawing.Size(76, 29)
        Me.Button1.TabIndex = 1
        Me.Button1.Text = "Add Picture"
        Me.Button1.UseVisualStyleBackColor = True
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Font = New System.Drawing.Font("Arial Narrow", 14.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.Location = New System.Drawing.Point(593, 562)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(133, 23)
        Me.Label1.TabIndex = 10
        Me.Label1.Text = "Car Plate Number"
        '
        'Button2
        '
        Me.Button2.Font = New System.Drawing.Font("PMingLiU", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(136, Byte))
        Me.Button2.Location = New System.Drawing.Point(410, 348)
        Me.Button2.Name = "Button2"
        Me.Button2.Size = New System.Drawing.Size(102, 29)
        Me.Button2.TabIndex = 11
        Me.Button2.Text = "Segmentation"
        Me.Button2.UseVisualStyleBackColor = True
        '
        'txtResult
        '
        Me.txtResult.Font = New System.Drawing.Font("Arial", 14.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtResult.ForeColor = System.Drawing.SystemColors.HotTrack
        Me.txtResult.Location = New System.Drawing.Point(579, 588)
        Me.txtResult.Name = "txtResult"
        Me.txtResult.Size = New System.Drawing.Size(157, 29)
        Me.txtResult.TabIndex = 12
        Me.txtResult.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'Button3
        '
        Me.Button3.Font = New System.Drawing.Font("PMingLiU", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(136, Byte))
        Me.Button3.Location = New System.Drawing.Point(119, 348)
        Me.Button3.Name = "Button3"
        Me.Button3.Size = New System.Drawing.Size(78, 29)
        Me.Button3.TabIndex = 13
        Me.Button3.Text = "BW Image"
        Me.Button3.UseVisualStyleBackColor = True
        '
        'Button4
        '
        Me.Button4.Font = New System.Drawing.Font("PMingLiU", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(136, Byte))
        Me.Button4.Location = New System.Drawing.Point(203, 348)
        Me.Button4.Name = "Button4"
        Me.Button4.Size = New System.Drawing.Size(75, 29)
        Me.Button4.TabIndex = 14
        Me.Button4.Text = "Crop Image"
        Me.Button4.UseVisualStyleBackColor = True
        '
        'Button5
        '
        Me.Button5.Font = New System.Drawing.Font("PMingLiU", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(136, Byte))
        Me.Button5.Location = New System.Drawing.Point(597, 348)
        Me.Button5.Name = "Button5"
        Me.Button5.Size = New System.Drawing.Size(140, 29)
        Me.Button5.TabIndex = 15
        Me.Button5.Text = "Recognize Number"
        Me.Button5.UseVisualStyleBackColor = True
        '
        'Timer1
        '
        Me.Timer1.Interval = 3000
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Location = New System.Drawing.Point(680, 686)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(37, 12)
        Me.Label2.TabIndex = 19
        Me.Label2.Text = "Label2"
        Me.Label2.Visible = False
        '
        'txtChar
        '
        Me.txtChar.Font = New System.Drawing.Font("Arial", 14.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtChar.ForeColor = System.Drawing.SystemColors.HotTrack
        Me.txtChar.Location = New System.Drawing.Point(579, 518)
        Me.txtChar.Name = "txtChar"
        Me.txtChar.Size = New System.Drawing.Size(157, 29)
        Me.txtChar.TabIndex = 21
        Me.txtChar.Text = "0"
        Me.txtChar.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Font = New System.Drawing.Font("Arial Narrow", 14.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label3.Location = New System.Drawing.Point(602, 491)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(115, 23)
        Me.Label3.TabIndex = 20
        Me.Label3.Text = "Total Character"
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Location = New System.Drawing.Point(680, 710)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(11, 12)
        Me.Label4.TabIndex = 22
        Me.Label4.Text = "1"
        Me.Label4.Visible = False
        '
        'Button7
        '
        Me.Button7.Font = New System.Drawing.Font("PMingLiU", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(136, Byte))
        Me.Button7.Location = New System.Drawing.Point(520, 348)
        Me.Button7.Name = "Button7"
        Me.Button7.Size = New System.Drawing.Size(69, 29)
        Me.Button7.TabIndex = 24
        Me.Button7.Text = "Scaling"
        Me.Button7.UseVisualStyleBackColor = True
        '
        'Button6
        '
        Me.Button6.Location = New System.Drawing.Point(32, 623)
        Me.Button6.Name = "Button6"
        Me.Button6.Size = New System.Drawing.Size(120, 23)
        Me.Button6.TabIndex = 25
        Me.Button6.Text = "Save"
        Me.Button6.UseVisualStyleBackColor = True
        '
        'Button8
        '
        Me.Button8.Location = New System.Drawing.Point(158, 623)
        Me.Button8.Name = "Button8"
        Me.Button8.Size = New System.Drawing.Size(120, 23)
        Me.Button8.TabIndex = 26
        Me.Button8.Text = "Save"
        Me.Button8.UseVisualStyleBackColor = True
        '
        'Button9
        '
        Me.Button9.Location = New System.Drawing.Point(284, 623)
        Me.Button9.Name = "Button9"
        Me.Button9.Size = New System.Drawing.Size(120, 23)
        Me.Button9.TabIndex = 27
        Me.Button9.Text = "Save"
        Me.Button9.UseVisualStyleBackColor = True
        '
        'Button10
        '
        Me.Button10.Location = New System.Drawing.Point(410, 623)
        Me.Button10.Name = "Button10"
        Me.Button10.Size = New System.Drawing.Size(120, 23)
        Me.Button10.TabIndex = 28
        Me.Button10.Text = "Save"
        Me.Button10.UseVisualStyleBackColor = True
        '
        'Button11
        '
        Me.Button11.Location = New System.Drawing.Point(410, 861)
        Me.Button11.Name = "Button11"
        Me.Button11.Size = New System.Drawing.Size(120, 23)
        Me.Button11.TabIndex = 32
        Me.Button11.Text = "Save"
        Me.Button11.UseVisualStyleBackColor = True
        '
        'Button12
        '
        Me.Button12.Location = New System.Drawing.Point(284, 861)
        Me.Button12.Name = "Button12"
        Me.Button12.Size = New System.Drawing.Size(120, 23)
        Me.Button12.TabIndex = 31
        Me.Button12.Text = "Save"
        Me.Button12.UseVisualStyleBackColor = True
        '
        'Button13
        '
        Me.Button13.Location = New System.Drawing.Point(158, 860)
        Me.Button13.Name = "Button13"
        Me.Button13.Size = New System.Drawing.Size(120, 23)
        Me.Button13.TabIndex = 30
        Me.Button13.Text = "Save"
        Me.Button13.UseVisualStyleBackColor = True
        '
        'Button14
        '
        Me.Button14.Location = New System.Drawing.Point(32, 860)
        Me.Button14.Name = "Button14"
        Me.Button14.Size = New System.Drawing.Size(120, 23)
        Me.Button14.TabIndex = 29
        Me.Button14.Text = "Save"
        Me.Button14.UseVisualStyleBackColor = True
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.Location = New System.Drawing.Point(577, 623)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(37, 12)
        Me.Label5.TabIndex = 33
        Me.Label5.Text = "Label5"
        Me.Label5.Visible = False
        '
        'Label6
        '
        Me.Label6.AutoSize = True
        Me.Label6.Location = New System.Drawing.Point(635, 623)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(37, 12)
        Me.Label6.TabIndex = 36
        Me.Label6.Text = "Label6"
        Me.Label6.Visible = False
        '
        'PictureBox3
        '
        Me.PictureBox3.BackColor = System.Drawing.Color.White
        Me.PictureBox3.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.PictureBox3.Location = New System.Drawing.Point(662, 655)
        Me.PictureBox3.Name = "PictureBox3"
        Me.PictureBox3.Size = New System.Drawing.Size(120, 200)
        Me.PictureBox3.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.PictureBox3.TabIndex = 34
        Me.PictureBox3.TabStop = False
        Me.PictureBox3.Visible = False
        '
        'picPlate
        '
        Me.picPlate.BackColor = System.Drawing.Color.White
        Me.picPlate.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None
        Me.picPlate.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.picPlate.Location = New System.Drawing.Point(37, 28)
        Me.picPlate.Name = "picPlate"
        Me.picPlate.Size = New System.Drawing.Size(700, 300)
        Me.picPlate.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.picPlate.TabIndex = 0
        Me.picPlate.TabStop = False
        Me.picPlate.Visible = False
        '
        'PictureBox2
        '
        Me.PictureBox2.BackColor = System.Drawing.Color.White
        Me.PictureBox2.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None
        Me.PictureBox2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.PictureBox2.Location = New System.Drawing.Point(37, 28)
        Me.PictureBox2.Name = "PictureBox2"
        Me.PictureBox2.Size = New System.Drawing.Size(700, 300)
        Me.PictureBox2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.PictureBox2.TabIndex = 17
        Me.PictureBox2.TabStop = False
        '
        'PictureBox1
        '
        Me.PictureBox1.BackColor = System.Drawing.Color.White
        Me.PictureBox1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.PictureBox1.Location = New System.Drawing.Point(536, 655)
        Me.PictureBox1.Name = "PictureBox1"
        Me.PictureBox1.Size = New System.Drawing.Size(120, 200)
        Me.PictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.PictureBox1.TabIndex = 16
        Me.PictureBox1.TabStop = False
        Me.PictureBox1.Visible = False
        '
        'crop8
        '
        Me.crop8.BackColor = System.Drawing.Color.White
        Me.crop8.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.crop8.Location = New System.Drawing.Point(410, 655)
        Me.crop8.Name = "crop8"
        Me.crop8.Size = New System.Drawing.Size(120, 200)
        Me.crop8.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.crop8.TabIndex = 9
        Me.crop8.TabStop = False
        '
        'crop7
        '
        Me.crop7.BackColor = System.Drawing.Color.White
        Me.crop7.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.crop7.Location = New System.Drawing.Point(284, 655)
        Me.crop7.Name = "crop7"
        Me.crop7.Size = New System.Drawing.Size(120, 200)
        Me.crop7.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.crop7.TabIndex = 8
        Me.crop7.TabStop = False
        '
        'crop6
        '
        Me.crop6.BackColor = System.Drawing.Color.White
        Me.crop6.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.crop6.Location = New System.Drawing.Point(158, 655)
        Me.crop6.Name = "crop6"
        Me.crop6.Size = New System.Drawing.Size(120, 200)
        Me.crop6.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.crop6.TabIndex = 7
        Me.crop6.TabStop = False
        '
        'crop5
        '
        Me.crop5.BackColor = System.Drawing.Color.White
        Me.crop5.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.crop5.Location = New System.Drawing.Point(32, 655)
        Me.crop5.Name = "crop5"
        Me.crop5.Size = New System.Drawing.Size(120, 200)
        Me.crop5.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.crop5.TabIndex = 6
        Me.crop5.TabStop = False
        '
        'crop4
        '
        Me.crop4.BackColor = System.Drawing.Color.White
        Me.crop4.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.crop4.Location = New System.Drawing.Point(410, 417)
        Me.crop4.Name = "crop4"
        Me.crop4.Size = New System.Drawing.Size(120, 200)
        Me.crop4.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.crop4.TabIndex = 5
        Me.crop4.TabStop = False
        '
        'crop3
        '
        Me.crop3.BackColor = System.Drawing.Color.White
        Me.crop3.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.crop3.Location = New System.Drawing.Point(284, 417)
        Me.crop3.Name = "crop3"
        Me.crop3.Size = New System.Drawing.Size(120, 200)
        Me.crop3.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.crop3.TabIndex = 4
        Me.crop3.TabStop = False
        '
        'crop2
        '
        Me.crop2.BackColor = System.Drawing.Color.White
        Me.crop2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.crop2.Location = New System.Drawing.Point(158, 417)
        Me.crop2.Name = "crop2"
        Me.crop2.Size = New System.Drawing.Size(120, 200)
        Me.crop2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.crop2.TabIndex = 3
        Me.crop2.TabStop = False
        '
        'crop1
        '
        Me.crop1.BackColor = System.Drawing.Color.White
        Me.crop1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.crop1.Location = New System.Drawing.Point(32, 417)
        Me.crop1.Name = "crop1"
        Me.crop1.Size = New System.Drawing.Size(120, 200)
        Me.crop1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.crop1.TabIndex = 2
        Me.crop1.TabStop = False
        '
        'TextBox1
        '
        Me.TextBox1.Location = New System.Drawing.Point(556, 382)
        Me.TextBox1.Name = "TextBox1"
        Me.TextBox1.Size = New System.Drawing.Size(100, 22)
        Me.TextBox1.TabIndex = 37
        Me.TextBox1.Visible = False
        '
        'TextBox2
        '
        Me.TextBox2.Location = New System.Drawing.Point(556, 410)
        Me.TextBox2.Name = "TextBox2"
        Me.TextBox2.Size = New System.Drawing.Size(100, 22)
        Me.TextBox2.TabIndex = 38
        Me.TextBox2.Visible = False
        '
        'TextBox3
        '
        Me.TextBox3.Location = New System.Drawing.Point(556, 438)
        Me.TextBox3.Name = "TextBox3"
        Me.TextBox3.Size = New System.Drawing.Size(100, 22)
        Me.TextBox3.TabIndex = 39
        Me.TextBox3.Visible = False
        '
        'TextBox4
        '
        Me.TextBox4.Location = New System.Drawing.Point(556, 466)
        Me.TextBox4.Name = "TextBox4"
        Me.TextBox4.Size = New System.Drawing.Size(100, 22)
        Me.TextBox4.TabIndex = 40
        Me.TextBox4.Visible = False
        '
        'TextBox5
        '
        Me.TextBox5.Location = New System.Drawing.Point(662, 466)
        Me.TextBox5.Name = "TextBox5"
        Me.TextBox5.Size = New System.Drawing.Size(100, 22)
        Me.TextBox5.TabIndex = 44
        Me.TextBox5.Visible = False
        '
        'TextBox6
        '
        Me.TextBox6.Location = New System.Drawing.Point(662, 438)
        Me.TextBox6.Name = "TextBox6"
        Me.TextBox6.Size = New System.Drawing.Size(100, 22)
        Me.TextBox6.TabIndex = 43
        Me.TextBox6.Visible = False
        '
        'TextBox7
        '
        Me.TextBox7.Location = New System.Drawing.Point(662, 410)
        Me.TextBox7.Name = "TextBox7"
        Me.TextBox7.Size = New System.Drawing.Size(100, 22)
        Me.TextBox7.TabIndex = 42
        Me.TextBox7.Visible = False
        '
        'TextBox8
        '
        Me.TextBox8.Location = New System.Drawing.Point(662, 382)
        Me.TextBox8.Name = "TextBox8"
        Me.TextBox8.Size = New System.Drawing.Size(100, 22)
        Me.TextBox8.TabIndex = 41
        Me.TextBox8.Visible = False
        '
        'Form1
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 12.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(800, 902)
        Me.Controls.Add(Me.TextBox5)
        Me.Controls.Add(Me.TextBox6)
        Me.Controls.Add(Me.TextBox7)
        Me.Controls.Add(Me.TextBox8)
        Me.Controls.Add(Me.TextBox4)
        Me.Controls.Add(Me.TextBox3)
        Me.Controls.Add(Me.TextBox2)
        Me.Controls.Add(Me.TextBox1)
        Me.Controls.Add(Me.Label6)
        Me.Controls.Add(Me.PictureBox3)
        Me.Controls.Add(Me.Label5)
        Me.Controls.Add(Me.Button11)
        Me.Controls.Add(Me.Button12)
        Me.Controls.Add(Me.Button13)
        Me.Controls.Add(Me.Button14)
        Me.Controls.Add(Me.Button10)
        Me.Controls.Add(Me.Button9)
        Me.Controls.Add(Me.Button8)
        Me.Controls.Add(Me.Button6)
        Me.Controls.Add(Me.Button7)
        Me.Controls.Add(Me.Label4)
        Me.Controls.Add(Me.txtChar)
        Me.Controls.Add(Me.Label3)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.picPlate)
        Me.Controls.Add(Me.PictureBox2)
        Me.Controls.Add(Me.PictureBox1)
        Me.Controls.Add(Me.Button5)
        Me.Controls.Add(Me.Button4)
        Me.Controls.Add(Me.Button3)
        Me.Controls.Add(Me.txtResult)
        Me.Controls.Add(Me.Button2)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.crop8)
        Me.Controls.Add(Me.crop7)
        Me.Controls.Add(Me.crop6)
        Me.Controls.Add(Me.crop5)
        Me.Controls.Add(Me.crop4)
        Me.Controls.Add(Me.crop3)
        Me.Controls.Add(Me.crop2)
        Me.Controls.Add(Me.crop1)
        Me.Controls.Add(Me.Button1)
        Me.MaximizeBox = False
        Me.MinimizeBox = False
        Me.Name = "Form1"
        Me.Text = "License Plate Number Detection -  Wahyu Rahmaniar"
        CType(Me.PictureBox3, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.picPlate, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox2, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.crop8, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.crop7, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.crop6, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.crop5, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.crop4, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.crop3, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.crop2, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.crop1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents picPlate As System.Windows.Forms.PictureBox
    Friend WithEvents Button1 As System.Windows.Forms.Button
    Friend WithEvents crop1 As System.Windows.Forms.PictureBox
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents Button2 As System.Windows.Forms.Button
    Friend WithEvents txtResult As System.Windows.Forms.TextBox
    Friend WithEvents Button3 As System.Windows.Forms.Button
    Friend WithEvents Button4 As System.Windows.Forms.Button
    Friend WithEvents Button5 As System.Windows.Forms.Button
    Friend WithEvents crop8 As System.Windows.Forms.PictureBox
    Friend WithEvents crop7 As System.Windows.Forms.PictureBox
    Friend WithEvents crop4 As System.Windows.Forms.PictureBox
    Friend WithEvents crop3 As System.Windows.Forms.PictureBox
    Friend WithEvents crop2 As System.Windows.Forms.PictureBox
    Friend WithEvents crop6 As System.Windows.Forms.PictureBox
    Friend WithEvents crop5 As System.Windows.Forms.PictureBox
    Friend WithEvents PictureBox1 As System.Windows.Forms.PictureBox
    Friend WithEvents Timer1 As System.Windows.Forms.Timer
    Friend WithEvents PictureBox2 As System.Windows.Forms.PictureBox
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents txtChar As System.Windows.Forms.TextBox
    Friend WithEvents Label3 As System.Windows.Forms.Label
    Friend WithEvents Label4 As System.Windows.Forms.Label
    Friend WithEvents Button7 As System.Windows.Forms.Button
    Friend WithEvents Button6 As System.Windows.Forms.Button
    Friend WithEvents Button8 As System.Windows.Forms.Button
    Friend WithEvents Button9 As System.Windows.Forms.Button
    Friend WithEvents Button10 As System.Windows.Forms.Button
    Friend WithEvents Button11 As System.Windows.Forms.Button
    Friend WithEvents Button12 As System.Windows.Forms.Button
    Friend WithEvents Button13 As System.Windows.Forms.Button
    Friend WithEvents Button14 As System.Windows.Forms.Button
    Friend WithEvents Label5 As System.Windows.Forms.Label
    Friend WithEvents PictureBox3 As System.Windows.Forms.PictureBox
    Friend WithEvents Label6 As System.Windows.Forms.Label
    Friend WithEvents TextBox1 As System.Windows.Forms.TextBox
    Friend WithEvents TextBox2 As System.Windows.Forms.TextBox
    Friend WithEvents TextBox3 As System.Windows.Forms.TextBox
    Friend WithEvents TextBox4 As System.Windows.Forms.TextBox
    Friend WithEvents TextBox5 As System.Windows.Forms.TextBox
    Friend WithEvents TextBox6 As System.Windows.Forms.TextBox
    Friend WithEvents TextBox7 As System.Windows.Forms.TextBox
    Friend WithEvents TextBox8 As System.Windows.Forms.TextBox

End Class
